#!/bin/sh
# Simple script to start ET: Legacy client/listen server with Omni-Bots
#
./etl +set omnibot_enable 1 +set omnibot_path "./legacy/omni-bot"
